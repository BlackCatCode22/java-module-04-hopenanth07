package com.hope.zoo;

public class App {
    public static void main(String[] args) {
        System.out.println("\n Welcome to my Zoo Keeper Challenge");

        Animal myNewAnimal = new Animal();

        System.out.println("\n myNewAnimal object's aniID is: " + myNewAnimal.getAnimalID());

        // get our animal an ID
        myNewAnimal.setAnimalID("1");
        System.out.println("\n ThesetAnimalID() method was called ! \n");
    }
}
